package com.akka


import java.util
import java.util.concurrent.ConcurrentLinkedQueue

import akka.actor.{ActorRef, ActorSystem}
import akka.dispatch._
import com.typesafe.config.Config


trait MyControlAwareMessageQueueSemantics

//myNote: you'll probably need to add your changes here.
trait MyControlMessage
case class AskControlMessage(message: Any) extends MyControlMessage
case class TellPresToSenderControlMessage(message: Any, flag: Boolean) extends MyControlMessage
case class TellControlMessage(message: Any) extends MyControlMessage


object MyControlAwareMailbox
{
	class MyControlAwareMessageQueue extends MessageQueue with MyControlAwareMessageQueueSemantics
	{
		private final var controlQueue : util.Queue[Envelope] = new ConcurrentLinkedQueue[Envelope]()
		private final val queue : util.Queue[Envelope] = new ConcurrentLinkedQueue[Envelope]()
		val history: Vector[Transition] = Vector.empty[Transition] //myNote: maybe this should be //val history: Vector[Transition] = new Vector[Transition]

		override def enqueue(receiver: ActorRef, handle: Envelope): Unit = handle match {
			case envelope @ Envelope(_: MyControlMessage, _) ⇒ controlQueue add envelope
			case envelope                                    ⇒ queue add envelope
		}

		override def dequeue(): Envelope =
		{
			val controlMsg = controlQueue.poll()

			if(controlMsg ne null) //myNote: you'll probably need to add your changes here.
				controlMsg.message match
				{
					//uncomment one on these two lines for exiting debugging.
					//case AskControlMessage(Transition(from, to, messageBundle, regTransition)) => tellStatusToSender(from, to, messageBundle, regTransition)
					case AskControlMessage(message) => print(message)
					case _ => print(s"match case failed")//TODO handle error
				}
			//TODO tell
			if (controlMsg ne null) controlMsg
			else queue.poll()
		}

		override def numberOfMessages: Int = queue.size() + controlQueue.size()

		override def hasMessages: Boolean = !(queue.isEmpty && controlQueue.isEmpty)

		//myNote: maybe we dont need cleanUp here.
		override def cleanUp(owner: ActorRef, deadLetters: MessageQueue): Unit = while (hasMessages) deadLetters.enqueue(owner, dequeue())

		def tellStatusToSender(from: Int, to: Int, messageBundle: MessageBundle, regTransiton: Boolean): Unit =
		{

			var answer = true
			var transition: Transition = new Transition(from, to, messageBundle, regTransiton)
			if(history.contains(transition))
				answer = true
			else
				answer = false
			//chizi ke baramoon oomade Pre e
			var tellControlMessage: TellPresToSenderControlMessage = new TellPresToSenderControlMessage(transition, answer)
			//TODO check history and automata, send a tell message to sender with msg and true/false, sender will erase that msg from his "Pres set"
			messageBundle.sender.tell(tellControlMessage, messageBundle.sender)
		}
	}
}

class MyControlAwareMailbox extends MailboxType with ProducesMessageQueue[MyControlAwareMailbox.MyControlAwareMessageQueue] {
	import MyControlAwareMailbox._

	def this(settings: ActorSystem.Settings, config: Config) = this()
	override def create(owner: Option[ActorRef], system: Option[ActorSystem]): MessageQueue = new MyControlAwareMessageQueue()
}






//myNote:
//	all my notes are taged with "//myNote"
//	enqueue and dequeue are used in dispatcher so they are called after dispatcher in the receiver side.
//	//TODO tellStatusToSender needs some heavy debugging.
