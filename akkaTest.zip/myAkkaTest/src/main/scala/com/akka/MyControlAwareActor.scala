package com.akka

import akka.actor.Actor
import akka.dispatch.RequiresMessageQueue

class MyControlAwareActor extends Actor /*with RequiresMessageQueue[MyControlAwareMessageQueueSemantics]*/ {

  def receive: PartialFunction[Any, Unit] = {

    // Int Messages
    case x: Int => println(x)
    // String Messages
    case x: String => println(x)
    // Long messages
    case x: Long => println(x)
    // other messages
    case x => println(x)
  }

}