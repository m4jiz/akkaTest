
package com.akka

import akka.actor.ActorSystem
import akka.actor.Props
import com.typesafe.config.ConfigFactory

object MyControlAwareTestApplication extends App {

	val system = ActorSystem("priority", ConfigFactory.load)

	val myControlAwareActor = system.actorOf(Props[MyControlAwareActor].withDispatcher("custom-dispatcher"))

	// send messages to actor

	val askMsg = AskControlMessage("yo im a CONTROL MESSAGE :")
	val askMsg2 = AskControlMessage("im getting processed sooner than normal messages : ")

	myControlAwareActor ! 6.0
	myControlAwareActor ! 1
	myControlAwareActor ! 5.0
	myControlAwareActor ! 3
	myControlAwareActor ! "Hello, this is a normal message"
	myControlAwareActor ! 5
	myControlAwareActor ! "I am control aware actor"
	myControlAwareActor ! "I process msgs from my control queue first"

	myControlAwareActor ! askMsg //type of this is MyControlMessage thus this is processed with priority
	myControlAwareActor ! askMsg2
}



//TODO : make this test run, using MyControlMessage trait and case match, then it is over.